create definer = root@localhost view emp_info as
select `s`.`name` AS `name`, `s`.`phone` AS `phone`, `sc`.`residence` AS `residence`
from (`myjoinsdb`.`employee_info` `s` left join `myjoinsdb`.`employee_info_add` `sc`
      on ((`s`.`id` = `sc`.`employee_id`)));

