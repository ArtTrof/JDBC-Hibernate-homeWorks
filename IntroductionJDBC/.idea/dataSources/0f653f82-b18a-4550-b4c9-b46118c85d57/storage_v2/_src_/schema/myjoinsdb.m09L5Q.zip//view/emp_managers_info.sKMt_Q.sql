create definer = root@localhost view emp_managers_info as
select `s`.`date_of_birth` AS `date_of_birth`, `sc`.`phone` AS `phone`, `sc`.`name` AS `name`
from ((`myjoinsdb`.`employee_info_add` `s` join `myjoinsdb`.`employee_info` `sc`
       on ((`s`.`employee_id` = `sc`.`id`))) join `myjoinsdb`.`employee_pos` `scs`
      on ((`scs`.`employee_id` = `sc`.`id`)))
where (`scs`.`job_pos` = 'Manager');

