create definer = root@localhost view emp_info_by_family_status as
select `s`.`date_of_birth` AS `date_of_birth`, `sc`.`phone` AS `phone`
from (`myjoinsdb`.`employee_info_add` `s` join `myjoinsdb`.`employee_info` `sc`
      on (((`s`.`employee_id` = `sc`.`id`) and (`s`.`family_status` = 'Single'))));

